def butaris_sample():
    print("hello world12345")
